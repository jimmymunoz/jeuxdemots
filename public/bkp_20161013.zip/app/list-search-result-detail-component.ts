import { Component, Input } from '@angular/core';
import { ResultDetail } from './result-detail';


const WordList : ResultDetail[] =  [
/*
  {definition: 'sqsqhsqsg'},
  {definition: 'sdds'},
  {definition: 'rtrt'},
  {definition: 'rtrt'},
  {definition: 'rtrt'},
  {definition: '131'}
*/
];

console.log(WordList);

@Component({
  selector: 'list-search-result-detail-component',
  
  //templateUrl: 'app/list_definition.html'
  //{{listResult | json}}
  template: `
    {{titre}}
    
    <div class="">
      <div class="row">
        <div class="col-md-3 left-menu">
          <div *ngFor="let key of keys(listResult.data)">
             <input type="checkbox" name="{{key}}" /> <span>{{key}}</span>
          </div>
        </div>
        <div class="col-md-9">
          <ul>
            <li *ngFor="let key of keys(listResult.data)">
               <b>{{key}}</b>
               <div>
                 {{listResult.data[key] | json}}
               </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  `
  ,styles: [`
    left-menu {
      display: block; border: 1px solid #ccc;
    }
  `]


  
})
//<list-definition [WordList]="selectedResultDetail"></list-definition>
export class ListSearchResultDetailComponent {
  //@Input()
  titre = "Result Details";
  //listResult = WordList;
  @Input()
  listResult : listResult;

  keys(object: {}) {
    if(! object ){
        object = [];
    }
    return Object.keys(object);
  }
}
