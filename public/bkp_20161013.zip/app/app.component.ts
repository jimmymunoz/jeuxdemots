import { Component } from '@angular/core';
import { NgForm }    from '@angular/common';
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";
//import { Word } from './words';
import { ResultDetail } from './result-detail';
import { WordService }   from './word.service';




@Component({
  selector: 'my-app',
  templateUrl: 'app/recherche.html',
  styles: [`
    ng2-auto-complete, input {
      display: block; border: 1px solid #ccc; width: 300px;
    }
  `],
   providers : [WordService]
})
export class Form {
	title = 'Mot a rechercher ';
	word = "bonjour";
	results = {};


	constructor(
	    private wordService: WordService,
	    //private router: Router
		private _sanitizer: DomSanitizer
	) { }


	save(): void {
	   	this.getSearchResult();	
	}
	getSearchResult(): void {
		this.wordService
		    .searchResults(this.word)
		    .then(
		    	results => this.results = results
		    );
	}

	
	leftAligned = (data: any) : SafeHtml => {
    	let html = `<div style="text-align:left">${data.value}</div>`;
    	return this._sanitizer.bypassSecurityTrustHtml(html);
  	}
  	completeCallBack(): void {
	   	this.getSearchResult();	
	}

	json(obj) {
		return JSON.stringify(obj);
	}
}

/*
 
npm install ng2-auto-complete --save
https://github.com/ng2-ui/ng2-auto-complete/blob/master/app/app.component.ts

 */