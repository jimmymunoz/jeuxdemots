export class ResultDetail {
	success: string;
	message: any;
	data: any;
}
